# PyMediaBrowser

A desktop Python web browser built with **PySide6 + Qt WebEngine**.

## Features

- Tabbed browsing
- Multimedia playback for standard HTML5 audio/video pages
- Fullscreen video support
- Downloads
- Find in page
- Bookmarks and history
- Open local files
- Save current page as PDF
- Persistent cookies and browser storage

## Quick start

```bash
cd python_multimedia_browser
./run_browser.sh
```

## Manual start

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip wheel
python -m pip install -r requirements.txt
python browser.py
```

## Notes

- Standard HTML5 media should work.
- Some DRM-protected streaming services may still fail unless Widevine is present on the system.
- Availability of some codecs depends on how Qt WebEngine was built.
